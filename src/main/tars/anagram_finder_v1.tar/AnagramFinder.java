import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Stream;

//TODO: add java docs
public class AnagramFinder {

    //TODO: refactor into methods as per logic flow
    public static void main(String[] args) {

        System.out.println("Welcome to the Anagram Finder");
        System.out.println("-----------------------------");

        if (args.length == 0) {
            System.out.println("No dictionary file name provided");
            return;
        }

        String fileName = args[0];
        String dir = System.getProperty("user.dir");
        Path path = Path.of(dir, fileName);

        Map<String, String> dictionary = new HashMap<>();

        long start = System.nanoTime();
        try (Stream<String> lines = Files.lines(path)) {

            lines.forEach((line) -> {
                char[] letters = line.toLowerCase().toCharArray();
                Arrays.sort(letters);
                String key = Arrays.toString(letters);

                if (dictionary.containsKey(key)) {
                    dictionary.put(key, dictionary.get(key) + "," + line);
                } else {
                    dictionary.put(key, line);
                }

            });
        } catch (Exception e) {
            e.printStackTrace(); //TODO: refactor exception handling
            return;
        }
        long end = System.nanoTime();
        long time = (end - start) / 1_000_000;

        String message = String.format("Dictionary loaded in %d ms", time);
        System.out.println(message);

        Scanner scanner = new Scanner(System.in);
        String input;
        do {
            System.out.print("\nAnagramFinder>");
            input = scanner.nextLine();

            start = System.nanoTime();
            char[] letters = input.toLowerCase().toCharArray();
            Arrays.sort(letters);
            String key = Arrays.toString(letters);

            if (dictionary.containsKey(key)) {
                String anagrams = dictionary.get(key);
                int anagramCount = anagrams.split(",").length;
                String plural = anagramCount == 1 ? "" : "s";
                end = System.nanoTime();
                time = (end - start) / 1_000_000;
                message = String.format(
                        "%d Anagram%s found for %s in %dms\n%s\n",
                        anagramCount, plural, input, time, anagrams
                );
            } else {
                end = System.nanoTime();
                time = (end - start) / 1_000_000;
                message = String.format("No anagrams found for %s in %dms\n", input, time);
            }

            System.out.println(message);

        } while (!input.equalsIgnoreCase("exit"));

        scanner.close();

    }
    
}
